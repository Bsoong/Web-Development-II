const tasksData = require("./tasks");

module.exports = {
  tasks: tasksData
};
